/* Care Dental — front-end form handling */
( function () {
	'use strict';

	if ( typeof CareDental === 'undefined' ) {
		return;
	}

	function serialize( form ) {
		var data = {};
		form.querySelectorAll( 'input, textarea, select' ).forEach( function ( el ) {
			if ( ! el.name ) {
				return;
			}
			if ( 'checkbox' === el.type ) {
				data[ el.name ] = el.checked ? '1' : '';
			} else {
				data[ el.name ] = el.value;
			}
		} );
		return data;
	}

	function setMsg( box, text, isError ) {
		box.textContent = text || '';
		box.className = 'caredental-msg' + ( isError ? ' is-error' : '' );
	}

	function handle( wrapper ) {
		var type   = wrapper.getAttribute( 'data-type' ) || 'booking';
		var btn    = wrapper.querySelector( '.caredental-submit' );
		var msg    = wrapper.querySelector( '.caredental-msg' );
		var fields = wrapper.querySelector( '.caredental-fields' );
		var done   = wrapper.querySelector( '.caredental-success' );
		var doneTx = wrapper.querySelector( '.caredental-success-text' );

		if ( ! btn ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			var data = serialize( wrapper );

			// Client-side validation.
			if ( ! data.firstName || ! data.phone ) {
				setMsg( msg, CareDental.i18n.required, true );
				return;
			}
			if ( 'contact' === type && ! data.message ) {
				setMsg( msg, CareDental.i18n.required, true );
				return;
			}
			if ( '1' !== data.consent ) {
				setMsg( msg, CareDental.i18n.consent, true );
				return;
			}

			setMsg( msg, '' );
			btn.disabled = true;
			var original = btn.textContent;
			btn.textContent = CareDental.i18n.sending;

			var body = new URLSearchParams();
			body.append( 'action', 'caredental_submit' );
			body.append( 'nonce', CareDental.nonce );
			body.append( 'type', type );
			Object.keys( data ).forEach( function ( k ) {
				body.append( k, data[ k ] );
			} );

			fetch( CareDental.ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			} )
			.then( function ( r ) { return r.json(); } )
			.then( function ( res ) {
				if ( res && res.success ) {
					if ( fields ) { fields.style.display = 'none'; }
					if ( done ) {
						done.hidden = false;
						if ( doneTx ) { doneTx.textContent = CareDental.i18n.thanks; }
					}
				} else {
					var m = res && res.data && res.data.message ? res.data.message : CareDental.i18n.error;
					setMsg( msg, m, true );
					btn.disabled = false;
					btn.textContent = original;
				}
			} )
			.catch( function () {
				setMsg( msg, CareDental.i18n.error, true );
				btn.disabled = false;
				btn.textContent = original;
			} );
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		document.querySelectorAll( '.caredental-form[data-type]' ).forEach( handle );
	} );
} )();
