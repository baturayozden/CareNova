/* Care Dental — admin settings */
( function () {
	'use strict';

	if ( typeof CareDentalAdmin === 'undefined' ) {
		return;
	}

	var keyInput = document.getElementById( 'caredental-key' );
	var connect  = document.getElementById( 'caredental-connect' );
	var status   = document.getElementById( 'caredental-status' );
	var step2    = document.getElementById( 'caredental-step2' );
	var step3    = document.getElementById( 'caredental-step3' );
	var waEnab   = document.getElementById( 'caredental-wa-enabled' );
	var waPos    = document.getElementById( 'caredental-wa-position' );
	var saveBtn  = document.getElementById( 'caredental-save' );
	var saveMsg  = document.getElementById( 'caredental-save-msg' );

	function post( action, extra ) {
		var body = new URLSearchParams();
		body.append( 'action', action );
		body.append( 'nonce', CareDentalAdmin.nonce );
		Object.keys( extra || {} ).forEach( function ( k ) {
			body.append( k, extra[ k ] );
		} );
		return fetch( CareDentalAdmin.ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString()
		} ).then( function ( r ) { return r.json(); } );
	}

	function unlock( el ) {
		if ( ! el ) { return; }
		el.style.opacity = '';
		el.style.pointerEvents = '';
	}

	if ( connect ) {
		connect.addEventListener( 'click', function () {
			var key = ( keyInput.value || '' ).trim();
			if ( ! key ) {
				status.className = 'caredental-status is-error';
				status.textContent = CareDentalAdmin.i18n.failed;
				return;
			}
			connect.disabled = true;
			var label = connect.textContent;
			connect.textContent = CareDentalAdmin.i18n.connecting;
			status.className = 'caredental-status';
			status.textContent = '';

			post( 'caredental_connect', { key: key } ).then( function ( res ) {
				connect.disabled = false;
				connect.textContent = label;
				if ( res && res.success ) {
					status.className = 'caredental-status is-connected';
					status.innerHTML = '\u2714 ' + CareDentalAdmin.i18n.connected + ': <strong>' + ( res.data.clinicName || '' ) + '</strong>';
					unlock( step2 );
					unlock( step3 );
					if ( res.data.whatsapp && waEnab ) {
						waEnab.disabled = false;
					}
				} else {
					status.className = 'caredental-status is-error';
					status.textContent = ( res && res.data && res.data.message ) ? res.data.message : CareDentalAdmin.i18n.failed;
				}
			} ).catch( function () {
				connect.disabled = false;
				connect.textContent = label;
				status.className = 'caredental-status is-error';
				status.textContent = CareDentalAdmin.i18n.failed;
			} );
		} );
	}

	if ( saveBtn ) {
		saveBtn.addEventListener( 'click', function () {
			saveBtn.disabled = true;
			post( 'caredental_save', {
				whatsapp_enabled: ( waEnab && waEnab.checked ) ? '1' : '0',
				whatsapp_position: waPos ? waPos.value : 'right'
			} ).then( function ( res ) {
				saveBtn.disabled = false;
				saveMsg.textContent = ( res && res.success ) ? CareDentalAdmin.i18n.saved : '';
				setTimeout( function () { saveMsg.textContent = ''; }, 2500 );
			} ).catch( function () {
				saveBtn.disabled = false;
			} );
		} );
	}
} )();
