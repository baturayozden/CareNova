<?php
/**
 * Plugin Name:       Care Dental
 * Plugin URI:        https://caredental.ai
 * Description:       Connect your website's booking and contact forms to CareDental. Enquiries land straight in your CareDental dashboard, with an optional WhatsApp button — all from a single API key. No technical setup.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.2
 * Author:            CareDental
 * Author URI:        https://caredental.ai
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       care-dental
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // No direct access.
}

define( 'CAREDENTAL_VERSION', '1.0.0' );
define( 'CAREDENTAL_API_BASE', 'https://api.caredental.ai' );
define( 'CAREDENTAL_PATH', plugin_dir_path( __FILE__ ) );
define( 'CAREDENTAL_URL', plugin_dir_url( __FILE__ ) );

require_once CAREDENTAL_PATH . 'includes/class-cd-api.php';
require_once CAREDENTAL_PATH . 'includes/class-cd-settings.php';
require_once CAREDENTAL_PATH . 'includes/class-cd-forms.php';
require_once CAREDENTAL_PATH . 'includes/class-cd-whatsapp.php';

/**
 * Boot the plugin.
 */
function caredental_init() {
	load_plugin_textdomain( 'care-dental', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	CD_Settings::instance();
	CD_Forms::instance();
	CD_WhatsApp::instance();
}
add_action( 'plugins_loaded', 'caredental_init' );

/**
 * On activation, set sensible defaults.
 */
function caredental_activate() {
	if ( false === get_option( 'caredental_settings' ) ) {
		add_option( 'caredental_settings', array(
			'site_key'         => '',
			'clinic_name'      => '',
			'whatsapp_phone'   => '',
			'whatsapp_enabled' => 0,
			'whatsapp_position'=> 'right',
			'connected'        => 0,
		) );
	}
}
register_activation_hook( __FILE__, 'caredental_activate' );

/**
 * Add a Settings link on the plugins list row.
 */
function caredental_settings_link( $links ) {
	$url = admin_url( 'options-general.php?page=care-dental' );
	$links[] = '<a href="' . esc_url( $url ) . '">' . esc_html__( 'Settings', 'care-dental' ) . '</a>';
	return $links;
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'caredental_settings_link' );
