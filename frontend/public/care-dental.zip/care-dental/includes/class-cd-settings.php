<?php
/**
 * Admin settings page: enter API key, Connect (auto-pulls clinic name +
 * WhatsApp number), toggle the WhatsApp button.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CD_Settings {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'wp_ajax_caredental_connect', array( $this, 'ajax_connect' ) );
		add_action( 'wp_ajax_caredental_save', array( $this, 'ajax_save' ) );
	}

	public function menu() {
		add_options_page(
			__( 'Care Dental', 'care-dental' ),
			__( 'Care Dental', 'care-dental' ),
			'manage_options',
			'care-dental',
			array( $this, 'render' )
		);
	}

	public function assets( $hook ) {
		if ( 'settings_page_care-dental' !== $hook ) {
			return;
		}
		wp_enqueue_style( 'caredental-admin', CAREDENTAL_URL . 'assets/css/cd-admin.css', array(), CAREDENTAL_VERSION );
		wp_enqueue_script( 'caredental-admin', CAREDENTAL_URL . 'assets/js/cd-admin.js', array(), CAREDENTAL_VERSION, true );
		wp_localize_script( 'caredental-admin', 'CareDentalAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'caredental_admin' ),
			'i18n'    => array(
				'connecting' => __( 'Connecting…', 'care-dental' ),
				'connected'  => __( 'Connected', 'care-dental' ),
				'failed'     => __( 'Connection failed', 'care-dental' ),
				'saved'      => __( 'Saved', 'care-dental' ),
			),
		) );
	}

	/**
	 * AJAX: validate key against CareDental, store clinic name + WhatsApp number.
	 */
	public function ajax_connect() {
		check_ajax_referer( 'caredental_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'care-dental' ) ) );
		}

		$key = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		if ( empty( $key ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter your API key.', 'care-dental' ) ) );
		}

		$config = CD_API::fetch_config( $key );
		if ( is_wp_error( $config ) ) {
			wp_send_json_error( array( 'message' => $config->get_error_message() ) );
		}

		$whatsapp = isset( $config['whatsappPhone'] ) ? preg_replace( '/[^0-9]/', '', (string) $config['whatsappPhone'] ) : '';

		CD_API::update( array(
			'site_key'       => $key,
			'clinic_name'    => isset( $config['clinicName'] ) ? sanitize_text_field( $config['clinicName'] ) : '',
			'whatsapp_phone' => $whatsapp,
			'connected'      => 1,
		) );

		wp_send_json_success( array(
			'clinicName'   => isset( $config['clinicName'] ) ? $config['clinicName'] : '',
			'whatsapp'     => $whatsapp,
			'showWhatsapp' => ! empty( $config['showWhatsapp'] ),
			'message'      => __( 'Connected successfully.', 'care-dental' ),
		) );
	}

	/**
	 * AJAX: save the WhatsApp button toggle / position.
	 */
	public function ajax_save() {
		check_ajax_referer( 'caredental_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'care-dental' ) ) );
		}

		$enabled  = isset( $_POST['whatsapp_enabled'] ) && '1' === $_POST['whatsapp_enabled'] ? 1 : 0;
		$position = isset( $_POST['whatsapp_position'] ) && 'left' === $_POST['whatsapp_position'] ? 'left' : 'right';

		CD_API::update( array(
			'whatsapp_enabled'  => $enabled,
			'whatsapp_position' => $position,
		) );

		wp_send_json_success( array( 'message' => __( 'Settings saved.', 'care-dental' ) ) );
	}

	public function render() {
		$connected = (int) CD_API::get( 'connected', 0 );
		$key       = CD_API::get( 'site_key', '' );
		$clinic    = CD_API::get( 'clinic_name', '' );
		$whatsapp  = CD_API::get( 'whatsapp_phone', '' );
		$wa_on     = (int) CD_API::get( 'whatsapp_enabled', 0 );
		$wa_pos    = CD_API::get( 'whatsapp_position', 'right' );
		?>
		<div class="wrap caredental-wrap">
			<h1><?php esc_html_e( 'Care Dental', 'care-dental' ); ?></h1>
			<p class="caredental-tagline"><?php esc_html_e( 'Connect your website to CareDental. Enter your key once — everything else is automatic.', 'care-dental' ); ?></p>

			<div class="caredental-card">
				<h2><?php esc_html_e( '1. Connect your account', 'care-dental' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Paste the API key from your CareDental dashboard, then click Connect. We will pull your clinic name and WhatsApp number automatically.', 'care-dental' ); ?></p>

				<div class="caredental-connect-row">
					<input type="text" id="caredental-key" class="regular-text" placeholder="cd_site_…" value="<?php echo esc_attr( $key ); ?>" autocomplete="off" />
					<button type="button" id="caredental-connect" class="button button-primary"><?php esc_html_e( 'Connect', 'care-dental' ); ?></button>
				</div>

				<div id="caredental-status" class="caredental-status <?php echo $connected ? 'is-connected' : ''; ?>">
					<?php if ( $connected ) : ?>
						<span class="dashicons dashicons-yes-alt"></span>
						<?php
						/* translators: %s: clinic name */
						printf( esc_html__( 'Connected: %s', 'care-dental' ), '<strong>' . esc_html( $clinic ) . '</strong>' );
						?>
					<?php endif; ?>
				</div>
			</div>

			<div class="caredental-card" id="caredental-step2" <?php echo $connected ? '' : 'style="opacity:.5;pointer-events:none;"'; ?>>
				<h2><?php esc_html_e( '2. Add a form to any page', 'care-dental' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Paste one of these shortcodes into any page or post (works in the WordPress editor and Elementor):', 'care-dental' ); ?></p>
				<table class="caredental-shortcodes">
					<tr>
						<td><code>[caredental_booking]</code></td>
						<td><?php esc_html_e( 'Booking / appointment request form', 'care-dental' ); ?></td>
					</tr>
					<tr>
						<td><code>[caredental_contact]</code></td>
						<td><?php esc_html_e( 'General contact form', 'care-dental' ); ?></td>
					</tr>
				</table>
			</div>

			<div class="caredental-card" id="caredental-step3" <?php echo $connected ? '' : 'style="opacity:.5;pointer-events:none;"'; ?>>
				<h2><?php esc_html_e( '3. WhatsApp button (optional)', 'care-dental' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Show a floating WhatsApp button so visitors can message your clinic directly. The number is pulled from CareDental — nothing to type.', 'care-dental' ); ?></p>

				<p class="caredental-wa-number">
					<?php if ( $whatsapp ) : ?>
						<?php esc_html_e( 'WhatsApp number on file:', 'care-dental' ); ?> <strong>+<?php echo esc_html( $whatsapp ); ?></strong>
					<?php else : ?>
						<em><?php esc_html_e( 'No WhatsApp number found on your CareDental account yet. The button will appear automatically once a number is added.', 'care-dental' ); ?></em>
					<?php endif; ?>
				</p>

				<label class="caredental-toggle">
					<input type="checkbox" id="caredental-wa-enabled" value="1" <?php checked( $wa_on, 1 ); ?> <?php echo $whatsapp ? '' : 'disabled'; ?> />
					<?php esc_html_e( 'Show floating WhatsApp button', 'care-dental' ); ?>
				</label>

				<p>
					<label for="caredental-wa-position"><?php esc_html_e( 'Position:', 'care-dental' ); ?></label>
					<select id="caredental-wa-position">
						<option value="right" <?php selected( $wa_pos, 'right' ); ?>><?php esc_html_e( 'Bottom right', 'care-dental' ); ?></option>
						<option value="left" <?php selected( $wa_pos, 'left' ); ?>><?php esc_html_e( 'Bottom left', 'care-dental' ); ?></option>
					</select>
				</p>

				<button type="button" id="caredental-save" class="button"><?php esc_html_e( 'Save', 'care-dental' ); ?></button>
				<span id="caredental-save-msg" class="caredental-save-msg"></span>
			</div>
		</div>
		<?php
	}
}
