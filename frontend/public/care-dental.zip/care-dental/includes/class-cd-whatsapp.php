<?php
/**
 * Optional floating WhatsApp button. Number is pulled from CareDental on connect.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CD_WhatsApp {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_footer', array( $this, 'render' ) );
	}

	public function render() {
		if ( ! CD_API::get( 'connected', 0 ) ) {
			return;
		}
		if ( ! CD_API::get( 'whatsapp_enabled', 0 ) ) {
			return;
		}
		$phone = preg_replace( '/[^0-9]/', '', (string) CD_API::get( 'whatsapp_phone', '' ) );
		if ( empty( $phone ) ) {
			return;
		}

		$pos     = 'left' === CD_API::get( 'whatsapp_position', 'right' ) ? 'left' : 'right';
		$wa_url  = 'https://wa.me/' . $phone;
		$label   = __( 'Chat on WhatsApp', 'care-dental' );
		?>
		<a class="caredental-wa-fab caredental-wa-<?php echo esc_attr( $pos ); ?>"
		   href="<?php echo esc_url( $wa_url ); ?>"
		   target="_blank" rel="noopener"
		   aria-label="<?php echo esc_attr( $label ); ?>">
			<svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true" focusable="false">
				<path fill="currentColor" d="M16 0C7.2 0 0 7.2 0 16c0 2.8.7 5.5 2.1 7.9L0 32l8.3-2.2C10.6 31.2 13.3 32 16 32c8.8 0 16-7.2 16-16S24.8 0 16 0zm0 29.3c-2.5 0-4.9-.7-7-1.9l-.5-.3-4.9 1.3 1.3-4.8-.3-.5c-1.4-2.2-2.1-4.7-2.1-7.1C2.5 8.6 8.6 2.5 16 2.5S29.5 8.6 29.5 16 23.4 29.3 16 29.3zm7.4-9.9c-.4-.2-2.4-1.2-2.7-1.3-.4-.1-.6-.2-.9.2-.3.4-1 1.3-1.2 1.5-.2.2-.4.3-.8.1-.4-.2-1.7-.6-3.3-2-1.2-1.1-2-2.4-2.3-2.8-.2-.4 0-.6.2-.8.2-.2.4-.4.6-.7.2-.2.3-.4.4-.7.1-.3.1-.5 0-.7-.1-.2-.9-2.2-1.2-3-.3-.8-.6-.7-.9-.7h-.8c-.3 0-.7.1-1.1.5-.4.4-1.5 1.4-1.5 3.5s1.5 4 1.7 4.3c.2.3 3 4.6 7.3 6.4 1 .4 1.8.7 2.4.9 1 .3 1.9.3 2.6.2.8-.1 2.4-1 2.7-1.9.3-.9.3-1.7.2-1.9-.1-.2-.4-.3-.8-.5z"/>
			</svg>
			<span class="caredental-wa-text"><?php echo esc_html( $label ); ?></span>
		</a>
		<?php
	}
}
