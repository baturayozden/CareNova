<?php
/**
 * Front-end forms: [caredental_booking] and [caredental_contact] shortcodes,
 * plus the AJAX handler that forwards submissions to CareDental server-side.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CD_Forms {

	private static $instance = null;
	private $enqueued = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_shortcode( 'caredental_booking', array( $this, 'booking' ) );
		add_shortcode( 'caredental_contact', array( $this, 'contact' ) );
		add_action( 'wp_ajax_caredental_submit', array( $this, 'ajax_submit' ) );
		add_action( 'wp_ajax_nopriv_caredental_submit', array( $this, 'ajax_submit' ) );
	}

	private function ensure_assets() {
		if ( $this->enqueued ) {
			return;
		}
		wp_enqueue_style( 'caredental-frontend', CAREDENTAL_URL . 'assets/css/cd-frontend.css', array(), CAREDENTAL_VERSION );
		wp_enqueue_script( 'caredental-frontend', CAREDENTAL_URL . 'assets/js/cd-frontend.js', array(), CAREDENTAL_VERSION, true );
		wp_localize_script( 'caredental-frontend', 'CareDental', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'caredental_submit' ),
			'i18n'    => array(
				'sending' => __( 'Sending…', 'care-dental' ),
				'thanks'  => __( 'Thank you — we have received your request and will be in touch shortly.', 'care-dental' ),
				'error'   => __( 'Something went wrong. Please try again or call the clinic.', 'care-dental' ),
				'required'=> __( 'Please complete the required fields.', 'care-dental' ),
				'consent' => __( 'Please tick the consent box to continue.', 'care-dental' ),
			),
		) );
		$this->enqueued = true;
	}

	private function not_connected_notice() {
		if ( current_user_can( 'manage_options' ) ) {
			return '<div class="caredental-form caredental-notice">' .
				esc_html__( 'Care Dental is not connected yet. Go to Settings → Care Dental and enter your API key.', 'care-dental' ) .
				'</div>';
		}
		return '';
	}

	public function booking( $atts ) {
		if ( ! CD_API::get( 'connected', 0 ) ) {
			return $this->not_connected_notice();
		}
		$this->ensure_assets();
		$atts = shortcode_atts( array(
			'title'  => __( 'Book an appointment', 'care-dental' ),
			'button' => __( 'Request appointment', 'care-dental' ),
		), $atts, 'caredental_booking' );

		return $this->render_form( 'booking', $atts['title'], $atts['button'] );
	}

	public function contact( $atts ) {
		if ( ! CD_API::get( 'connected', 0 ) ) {
			return $this->not_connected_notice();
		}
		$this->ensure_assets();
		$atts = shortcode_atts( array(
			'title'  => __( 'Contact us', 'care-dental' ),
			'button' => __( 'Send message', 'care-dental' ),
		), $atts, 'caredental_contact' );

		return $this->render_form( 'contact', $atts['title'], $atts['button'] );
	}

	private function render_form( $type, $title, $button ) {
		$is_booking = ( 'booking' === $type );
		ob_start();
		?>
		<div class="caredental-form" data-type="<?php echo esc_attr( $type ); ?>">
			<h3 class="caredental-form-title"><?php echo esc_html( $title ); ?></h3>

			<div class="caredental-fields">
				<div class="caredental-row">
					<label><?php esc_html_e( 'First name', 'care-dental' ); ?> <span>*</span>
						<input type="text" name="firstName" required />
					</label>
					<label><?php esc_html_e( 'Last name', 'care-dental' ); ?>
						<input type="text" name="lastName" />
					</label>
				</div>

				<div class="caredental-row">
					<label><?php esc_html_e( 'Phone', 'care-dental' ); ?> <span>*</span>
						<input type="tel" name="phone" required placeholder="07…" />
					</label>
					<label><?php esc_html_e( 'Email', 'care-dental' ); ?>
						<input type="email" name="email" />
					</label>
				</div>

				<?php if ( $is_booking ) : ?>
					<div class="caredental-row">
						<label><?php esc_html_e( 'Treatment of interest', 'care-dental' ); ?>
							<input type="text" name="treatment" placeholder="<?php esc_attr_e( 'e.g. Implants, Veneers', 'care-dental' ); ?>" />
						</label>
						<label><?php esc_html_e( 'Preferred date / time', 'care-dental' ); ?>
							<input type="text" name="preferredDate" placeholder="<?php esc_attr_e( 'e.g. Next week, mornings', 'care-dental' ); ?>" />
						</label>
					</div>
					<label class="caredental-full"><?php esc_html_e( 'Message (optional)', 'care-dental' ); ?>
						<textarea name="message" rows="3"></textarea>
					</label>
				<?php else : ?>
					<label class="caredental-full"><?php esc_html_e( 'Message', 'care-dental' ); ?> <span>*</span>
						<textarea name="message" rows="4" required></textarea>
					</label>
				<?php endif; ?>

				<label class="caredental-consent">
					<input type="checkbox" name="consent" value="1" />
					<span><?php esc_html_e( 'I agree to be contacted about my enquiry, including via WhatsApp.', 'care-dental' ); ?> <span class="req">*</span></span>
				</label>

				<?php /* Honeypot: hidden from humans, bots fill it. */ ?>
				<div class="caredental-hp" aria-hidden="true">
					<label><?php esc_html_e( 'Leave this field empty', 'care-dental' ); ?>
						<input type="text" name="_gotcha" tabindex="-1" autocomplete="off" />
					</label>
				</div>

				<button type="button" class="caredental-submit"><?php echo esc_html( $button ); ?></button>
				<div class="caredental-msg" role="status" aria-live="polite"></div>
			</div>

			<div class="caredental-success" hidden>
				<div class="caredental-check">&#10003;</div>
				<p class="caredental-success-text"></p>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * AJAX: receive a submission from the browser, validate, forward to CareDental.
	 */
	public function ajax_submit() {
		check_ajax_referer( 'caredental_submit', 'nonce' );

		$type = isset( $_POST['type'] ) && 'contact' === $_POST['type'] ? 'contact' : 'booking';

		// Honeypot: if filled, silently accept without forwarding.
		if ( ! empty( $_POST['_gotcha'] ) ) {
			wp_send_json_success( array( 'ok' => true ) );
		}

		$first   = isset( $_POST['firstName'] ) ? sanitize_text_field( wp_unslash( $_POST['firstName'] ) ) : '';
		$last    = isset( $_POST['lastName'] ) ? sanitize_text_field( wp_unslash( $_POST['lastName'] ) ) : '';
		$phone   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$email   = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
		$message = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
		$consent = isset( $_POST['consent'] ) && '1' === $_POST['consent'];

		if ( empty( $first ) || empty( $phone ) ) {
			wp_send_json_error( array( 'message' => __( 'Please complete the required fields.', 'care-dental' ) ) );
		}
		if ( 'contact' === $type && empty( $message ) ) {
			wp_send_json_error( array( 'message' => __( 'Please enter a message.', 'care-dental' ) ) );
		}

		$payload = array(
			'firstName' => $first,
			'lastName'  => $last,
			'phone'     => $phone,
			'email'     => $email,
			'message'   => $message,
			'consent'   => $consent,
		);

		if ( 'booking' === $type ) {
			$payload['treatment']     = isset( $_POST['treatment'] ) ? sanitize_text_field( wp_unslash( $_POST['treatment'] ) ) : '';
			$payload['preferredDate'] = isset( $_POST['preferredDate'] ) ? sanitize_text_field( wp_unslash( $_POST['preferredDate'] ) ) : '';
		}

		$result = CD_API::submit( $type, $payload );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'ok' => true ) );
	}
}
