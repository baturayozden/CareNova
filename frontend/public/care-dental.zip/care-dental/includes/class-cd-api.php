<?php
/**
 * CareDental API client. All calls run server-side (PHP), so the API key
 * never reaches the visitor's browser.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CD_API {

	/**
	 * Read a single setting.
	 */
	public static function get( $key, $default = '' ) {
		$settings = get_option( 'caredental_settings', array() );
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Update settings (merged).
	 */
	public static function update( $patch ) {
		$settings = get_option( 'caredental_settings', array() );
		$settings = array_merge( is_array( $settings ) ? $settings : array(), $patch );
		update_option( 'caredental_settings', $settings );
		return $settings;
	}

	/**
	 * Validate a key and pull clinic config from CareDental.
	 * Returns array { clinicName, whatsappPhone, showWhatsapp, treatments } or WP_Error.
	 */
	public static function fetch_config( $key = null ) {
		$key = $key ? trim( $key ) : self::get( 'site_key' );
		if ( empty( $key ) ) {
			return new WP_Error( 'no_key', __( 'No API key set.', 'care-dental' ) );
		}

		$url  = CAREDENTAL_API_BASE . '/api/widget/config?siteKey=' . rawurlencode( $key );
		$resp = wp_remote_get( $url, array( 'timeout' => 15 ) );

		if ( is_wp_error( $resp ) ) {
			return $resp;
		}

		$code = wp_remote_retrieve_response_code( $resp );
		$body = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( 200 !== (int) $code || ! is_array( $body ) ) {
			$msg = is_array( $body ) && isset( $body['error'] ) ? $body['error'] : __( 'Invalid API key or connection error.', 'care-dental' );
			return new WP_Error( 'invalid_key', $msg );
		}

		return $body;
	}

	/**
	 * Submit a booking or contact enquiry.
	 * $type = 'booking' | 'contact'.
	 */
	public static function submit( $type, $data ) {
		$key = self::get( 'site_key' );
		if ( empty( $key ) ) {
			return new WP_Error( 'no_key', __( 'This site is not connected to CareDental yet.', 'care-dental' ) );
		}

		$endpoint = ( 'contact' === $type ) ? '/api/widget/contact' : '/api/widget/booking';
		$data['siteKey'] = $key;

		$resp = wp_remote_post( CAREDENTAL_API_BASE . $endpoint, array(
			'timeout' => 15,
			'headers' => array( 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $data ),
		) );

		if ( is_wp_error( $resp ) ) {
			return $resp;
		}

		$code = wp_remote_retrieve_response_code( $resp );
		$body = json_decode( wp_remote_retrieve_body( $resp ), true );

		if ( $code >= 200 && $code < 300 ) {
			return is_array( $body ) ? $body : array( 'ok' => true );
		}

		$msg = is_array( $body ) && isset( $body['error'] ) ? $body['error'] : __( 'Submission failed. Please try again.', 'care-dental' );
		return new WP_Error( 'submit_failed', $msg );
	}
}
