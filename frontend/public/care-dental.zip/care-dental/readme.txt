=== Care Dental ===
Contributors: caredental
Tags: dental, booking, contact form, whatsapp, lead capture
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Connect your dental website's booking and contact forms to CareDental. Enquiries land straight in your dashboard, with an optional WhatsApp button — all from one API key.

== Description ==

Care Dental connects your WordPress website to your [CareDental](https://caredental.ai) account. Add a booking or contact form to any page with a simple shortcode, and every enquiry is captured directly in your CareDental dashboard where your AI assistant can follow up automatically.

**Zero technical setup.** Paste your API key once and the plugin pulls your clinic name and WhatsApp number automatically. Your team doesn't configure anything else.

= Features =

* Booking form shortcode: `[caredental_booking]`
* Contact form shortcode: `[caredental_contact]`
* Optional floating WhatsApp button (number pulled from CareDental automatically)
* Works in the WordPress block editor and Elementor
* Server-side submission — your API key never reaches the visitor's browser
* Built-in spam protection (honeypot + nonce)
* GDPR-friendly consent checkbox

= How it works =

1. Install and activate the plugin.
2. Go to Settings → Care Dental and paste your CareDental API key.
3. Click Connect — your clinic name and WhatsApp number are pulled in automatically.
4. Add `[caredental_booking]` or `[caredental_contact]` to any page.

Enquiries appear in your CareDental dashboard, tagged as website leads.

== Installation ==

1. Upload the `care-dental` folder to `/wp-content/plugins/`, or install the ZIP via Plugins → Add New → Upload Plugin.
2. Activate the plugin through the Plugins menu.
3. Go to Settings → Care Dental and enter your API key.

== Frequently Asked Questions ==

= Where do I get an API key? =

From your CareDental dashboard. If you don't have a CareDental account, visit https://caredental.ai.

= Does my API key get exposed on my website? =

No. All communication with CareDental happens server-side from WordPress. The key is never sent to the visitor's browser.

= Does it work with Elementor? =

Yes. Use the shortcode in an Elementor Shortcode widget, or in any text/HTML block.

== Changelog ==

= 1.0.0 =
* Initial release: booking + contact shortcodes, auto-connect, WhatsApp button.
